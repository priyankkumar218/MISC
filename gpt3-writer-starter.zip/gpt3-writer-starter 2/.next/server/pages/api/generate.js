"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/generate";
exports.ids = ["pages/api/generate"];
exports.modules = {

/***/ "openai":
/*!*************************!*\
  !*** external "openai" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("openai");

/***/ }),

/***/ "(api)/./pages/api/generate.js":
/*!*******************************!*\
  !*** ./pages/api/generate.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var openai__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! openai */ \"openai\");\n/* harmony import */ var openai__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(openai__WEBPACK_IMPORTED_MODULE_0__);\n\nconst configuration = new openai__WEBPACK_IMPORTED_MODULE_0__.Configuration({\n    apiKey: process.env.OPENAI_API_KEY\n});\nconst openai = new openai__WEBPACK_IMPORTED_MODULE_0__.OpenAIApi(configuration);\nconst basePromptPrefix = `\nSuggest a great unique idea for developing a video game. Please tell briefly about the plot, storyline and tech stack.\n\nTitle:\n`;\nconst generateAction = async (req, res)=>{\n    // Run first prompt\n    console.log(`API: ${basePromptPrefix}${req.body.userInput}`);\n    const baseCompletion = await openai.createCompletion({\n        model: \"text-davinci-003\",\n        prompt: `${basePromptPrefix}${req.body.userInput}\\n`,\n        temperature: 0.8,\n        max_tokens: 250\n    });\n    const basePromptOutput = baseCompletion.data.choices.pop();\n    // I build Prompt #2.\n    const secondPrompt = `\n  Take the User Ask and Idea below. Make it feel like a story. Don't just list the points. Go deep into each one. Explain why.\n\n  User Ask: ${req.body.userInput}\n\n  Idea: ${basePromptOutput.text}\n\n  In-Depth Idea:\n  `;\n    // I call the OpenAI API a second time with Prompt #2\n    const secondPromptCompletion = await openai.createCompletion({\n        model: \"text-davinci-003\",\n        prompt: `${secondPrompt}`,\n        // I set a higher temperature for this one. Up to you!\n        temperature: 0.85,\n        // I also increase max_tokens.\n        max_tokens: 1250\n    });\n    // Get the output\n    const secondPromptOutput = secondPromptCompletion.data.choices.pop();\n    // Send over the Prompt #2's output to our UI instead of Prompt #1's.\n    res.status(200).json({\n        output: secondPromptOutput\n    });\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (generateAction);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvZ2VuZXJhdGUuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQWtEO0FBRWxELE1BQU1FLGdCQUFnQixJQUFJRixpREFBYUEsQ0FBQztJQUN0Q0csUUFBUUMsUUFBUUMsR0FBRyxDQUFDQyxjQUFjO0FBQ3BDO0FBRUEsTUFBTUMsU0FBUyxJQUFJTiw2Q0FBU0EsQ0FBQ0M7QUFFN0IsTUFBTU0sbUJBQ04sQ0FBQzs7OztBQUlELENBQUM7QUFDRCxNQUFNQyxpQkFBaUIsT0FBT0MsS0FBS0MsTUFBUTtJQUN6QyxtQkFBbUI7SUFDbkJDLFFBQVFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssRUFBRUwsaUJBQWlCLEVBQUVFLElBQUlJLElBQUksQ0FBQ0MsU0FBUyxDQUFDLENBQUM7SUFFM0QsTUFBTUMsaUJBQWlCLE1BQU1ULE9BQU9VLGdCQUFnQixDQUFDO1FBQ25EQyxPQUFPO1FBQ1BDLFFBQVEsQ0FBQyxFQUFFWCxpQkFBaUIsRUFBRUUsSUFBSUksSUFBSSxDQUFDQyxTQUFTLENBQUMsRUFBRSxDQUFDO1FBQ3BESyxhQUFhO1FBQ2JDLFlBQVk7SUFDZDtJQUVBLE1BQU1DLG1CQUFtQk4sZUFBZU8sSUFBSSxDQUFDQyxPQUFPLENBQUNDLEdBQUc7SUFFeEQscUJBQXFCO0lBQ3JCLE1BQU1DLGVBQ04sQ0FBQzs7O1lBR1MsRUFBRWhCLElBQUlJLElBQUksQ0FBQ0MsU0FBUyxDQUFDOztRQUV6QixFQUFFTyxpQkFBaUJLLElBQUksQ0FBQzs7O0VBRzlCLENBQUM7SUFFRCxxREFBcUQ7SUFDckQsTUFBTUMseUJBQXlCLE1BQU1yQixPQUFPVSxnQkFBZ0IsQ0FBQztRQUMzREMsT0FBTztRQUNQQyxRQUFRLENBQUMsRUFBRU8sYUFBYSxDQUFDO1FBQ3pCLHNEQUFzRDtRQUN0RE4sYUFBYTtRQUNmLDhCQUE4QjtRQUM1QkMsWUFBWTtJQUNkO0lBRUEsaUJBQWlCO0lBQ2pCLE1BQU1RLHFCQUFxQkQsdUJBQXVCTCxJQUFJLENBQUNDLE9BQU8sQ0FBQ0MsR0FBRztJQUVsRSxxRUFBcUU7SUFDckVkLElBQUltQixNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO1FBQUVDLFFBQVFIO0lBQW1CO0FBQ3BEO0FBRUEsaUVBQWVwQixjQUFjQSxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vc2NyYXRjaHBhZC8uL3BhZ2VzL2FwaS9nZW5lcmF0ZS5qcz82MjdjIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IENvbmZpZ3VyYXRpb24sIE9wZW5BSUFwaSB9IGZyb20gJ29wZW5haSc7XG5cbmNvbnN0IGNvbmZpZ3VyYXRpb24gPSBuZXcgQ29uZmlndXJhdGlvbih7XG4gIGFwaUtleTogcHJvY2Vzcy5lbnYuT1BFTkFJX0FQSV9LRVksXG59KTtcblxuY29uc3Qgb3BlbmFpID0gbmV3IE9wZW5BSUFwaShjb25maWd1cmF0aW9uKTtcblxuY29uc3QgYmFzZVByb21wdFByZWZpeCA9IFxuYFxuU3VnZ2VzdCBhIGdyZWF0IHVuaXF1ZSBpZGVhIGZvciBkZXZlbG9waW5nIGEgdmlkZW8gZ2FtZS4gUGxlYXNlIHRlbGwgYnJpZWZseSBhYm91dCB0aGUgcGxvdCwgc3RvcnlsaW5lIGFuZCB0ZWNoIHN0YWNrLlxuXG5UaXRsZTpcbmA7XG5jb25zdCBnZW5lcmF0ZUFjdGlvbiA9IGFzeW5jIChyZXEsIHJlcykgPT4ge1xuICAvLyBSdW4gZmlyc3QgcHJvbXB0XG4gIGNvbnNvbGUubG9nKGBBUEk6ICR7YmFzZVByb21wdFByZWZpeH0ke3JlcS5ib2R5LnVzZXJJbnB1dH1gKVxuXG4gIGNvbnN0IGJhc2VDb21wbGV0aW9uID0gYXdhaXQgb3BlbmFpLmNyZWF0ZUNvbXBsZXRpb24oe1xuICAgIG1vZGVsOiAndGV4dC1kYXZpbmNpLTAwMycsXG4gICAgcHJvbXB0OiBgJHtiYXNlUHJvbXB0UHJlZml4fSR7cmVxLmJvZHkudXNlcklucHV0fVxcbmAsXG4gICAgdGVtcGVyYXR1cmU6IDAuOCxcbiAgICBtYXhfdG9rZW5zOiAyNTAsXG4gIH0pO1xuICBcbiAgY29uc3QgYmFzZVByb21wdE91dHB1dCA9IGJhc2VDb21wbGV0aW9uLmRhdGEuY2hvaWNlcy5wb3AoKTtcblxuICAvLyBJIGJ1aWxkIFByb21wdCAjMi5cbiAgY29uc3Qgc2Vjb25kUHJvbXB0ID0gXG4gIGBcbiAgVGFrZSB0aGUgVXNlciBBc2sgYW5kIElkZWEgYmVsb3cuIE1ha2UgaXQgZmVlbCBsaWtlIGEgc3RvcnkuIERvbid0IGp1c3QgbGlzdCB0aGUgcG9pbnRzLiBHbyBkZWVwIGludG8gZWFjaCBvbmUuIEV4cGxhaW4gd2h5LlxuXG4gIFVzZXIgQXNrOiAke3JlcS5ib2R5LnVzZXJJbnB1dH1cblxuICBJZGVhOiAke2Jhc2VQcm9tcHRPdXRwdXQudGV4dH1cblxuICBJbi1EZXB0aCBJZGVhOlxuICBgXG5cbiAgLy8gSSBjYWxsIHRoZSBPcGVuQUkgQVBJIGEgc2Vjb25kIHRpbWUgd2l0aCBQcm9tcHQgIzJcbiAgY29uc3Qgc2Vjb25kUHJvbXB0Q29tcGxldGlvbiA9IGF3YWl0IG9wZW5haS5jcmVhdGVDb21wbGV0aW9uKHtcbiAgICBtb2RlbDogJ3RleHQtZGF2aW5jaS0wMDMnLFxuICAgIHByb21wdDogYCR7c2Vjb25kUHJvbXB0fWAsXG4gICAgLy8gSSBzZXQgYSBoaWdoZXIgdGVtcGVyYXR1cmUgZm9yIHRoaXMgb25lLiBVcCB0byB5b3UhXG4gICAgdGVtcGVyYXR1cmU6IDAuODUsXG5cdFx0Ly8gSSBhbHNvIGluY3JlYXNlIG1heF90b2tlbnMuXG4gICAgbWF4X3Rva2VuczogMTI1MCxcbiAgfSk7XG5cbiAgLy8gR2V0IHRoZSBvdXRwdXRcbiAgY29uc3Qgc2Vjb25kUHJvbXB0T3V0cHV0ID0gc2Vjb25kUHJvbXB0Q29tcGxldGlvbi5kYXRhLmNob2ljZXMucG9wKCk7XG5cbiAgLy8gU2VuZCBvdmVyIHRoZSBQcm9tcHQgIzIncyBvdXRwdXQgdG8gb3VyIFVJIGluc3RlYWQgb2YgUHJvbXB0ICMxJ3MuXG4gIHJlcy5zdGF0dXMoMjAwKS5qc29uKHsgb3V0cHV0OiBzZWNvbmRQcm9tcHRPdXRwdXQgfSk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBnZW5lcmF0ZUFjdGlvbjsiXSwibmFtZXMiOlsiQ29uZmlndXJhdGlvbiIsIk9wZW5BSUFwaSIsImNvbmZpZ3VyYXRpb24iLCJhcGlLZXkiLCJwcm9jZXNzIiwiZW52IiwiT1BFTkFJX0FQSV9LRVkiLCJvcGVuYWkiLCJiYXNlUHJvbXB0UHJlZml4IiwiZ2VuZXJhdGVBY3Rpb24iLCJyZXEiLCJyZXMiLCJjb25zb2xlIiwibG9nIiwiYm9keSIsInVzZXJJbnB1dCIsImJhc2VDb21wbGV0aW9uIiwiY3JlYXRlQ29tcGxldGlvbiIsIm1vZGVsIiwicHJvbXB0IiwidGVtcGVyYXR1cmUiLCJtYXhfdG9rZW5zIiwiYmFzZVByb21wdE91dHB1dCIsImRhdGEiLCJjaG9pY2VzIiwicG9wIiwic2Vjb25kUHJvbXB0IiwidGV4dCIsInNlY29uZFByb21wdENvbXBsZXRpb24iLCJzZWNvbmRQcm9tcHRPdXRwdXQiLCJzdGF0dXMiLCJqc29uIiwib3V0cHV0Il0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/generate.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/generate.js"));
module.exports = __webpack_exports__;

})();